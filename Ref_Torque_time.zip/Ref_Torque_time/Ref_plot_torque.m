clc
clear
load('Ref_torque_time.mat')
hold on
plot(yout1(:,1),yout1(:,2),'-k','LineWidth',2);%
plot(yout1(:,1),yout1(:,3),'-r','LineWidth',2);%
plot(yout1(:,1),yout1(:,4),'-b','LineWidth',2);%
plot(yout1(:,1),yout1(:,5),'-y','LineWidth',2);%
ylabel('$T_{1},T_{2},T_{3},T_{4},\theta_{f}$ $(N\cdot m)$','interpreter', 'latex');%
xlabel('$t/s$','interpreter', 'latex');%
leg = legend('$T_{1}$','$T_{2}$','$T_{3}$','$T_{4}$','$\theta_{f}$','interpreter', 'latex');
leg.ItemTokenSize = [40,20];
hold on 
%%%%yout1(:,1) refer to time
%%%%yout1(:,2) refer to the torrque of left front tire
%%%%yout1(:,3) refer to the torrque of right front tire
%%%%yout1(:,4) refer to the torrque of left rear tire
%%%%yout1(:,3) refer to the torrque of right rear tire
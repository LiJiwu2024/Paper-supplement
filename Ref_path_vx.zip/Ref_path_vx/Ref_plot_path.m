figure(7) 
hold on 
plot(yout(:,2),yout(:,3),'-b','LineWidth',2);
ylabel('$Y/m$','interpreter', 'latex');
xlabel('$X/m$','interpreter', 'latex');
leg = legend('Reference path','interpreter', 'latex');
% leg.ItemTokenSize = [40,30];
% hold on
%%%%yout1(:,1) refer to time
%%%%yout1(:,2) refer to the desired longitudinal trajectory of the vehicle
%%%%yout1(:,3) refer to the desired lateral trajectory of the vehicle
%%%%yout1(:,4) refer to the torrque of left rear tire
%%%%yout1(:,3) refer to the desired longitudinal speed of the vehicle
figure(3) 
hold on 
plot(yout(:,1),yout(:,5),'-k','LineWidth',2);
axis([0, 40, 0, 35]);
ylabel('$v_{x}/m/s$','interpreter', 'latex');
xlabel('$t/s$','interpreter','latex');
leg = legend('$v_{x}$','interpreter', 'latex');
leg.ItemTokenSize = [40,20];
hold on 
%%%%yout1(:,1) refer to time
%%%%yout1(:,2) refer to the desired longitudinal trajectory of the vehicle
%%%%yout1(:,3) refer to the desired lateral trajectory of the vehicle
%%%%yout1(:,4) refer to the torrque of left rear tire
%%%%yout1(:,3) refer to the desired longitudinal speed of the vehicle
# Paper-supplement
Supplementary materials for the paper "Low-Complexity Quantized Prescribed Performance Control for Constrained Steer-by-Wire Systems with Input Nonlinearity and Bandwidth Limitations"
